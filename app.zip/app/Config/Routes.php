<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
// Admin
$routes->get('/dashboard', 'Admin\Dashboard::index', ['filter' => 'role:admin']);
$routes->get('/data-barang', 'Admin\Barang::index', ['filter' => 'role:admin']);
$routes->get('/data-barang/(:any)', 'Admin\Barang::detail/$1', ['filter' => 'role:admin']);
$routes->get('/tambah-barang', 'Admin\Barang::tambah', ['filter' => 'role:admin']);
$routes->get('/data-banner', 'Admin\Banner::index', ['filter' => 'role:admin']);
$routes->get('/data-banner/(:any)', 'Admin\Banner::detail/$1', ['filter' => 'role:admin']);
$routes->get('/tambah-banner', 'Admin\Banner::tambah', ['filter' => 'role:admin']);
$routes->get('/data-pembayaran', 'Admin\Pembayaran::index', ['filter' => 'role:admin']);
$routes->get('/data-pembayaran/(:any)', 'Admin\Pembayaran::detail/$1', ['filter' => 'role:admin']);
$routes->get('/data-transaksi', 'Admin\Transaksi::index', ['filter' => 'role:admin']);
$routes->get('/data-transaksi/(:any)', 'Admin\Transaksi::detail/$1', ['filter' => 'role:admin']);
$routes->get('/data-users', 'Admin\Users::index', ['filter' => 'role:admin']);

// Guest
$routes->get('/', 'Guest\Home::index');
$routes->get('/beranda', 'Guest\Home::beranda');
$routes->get('/about', 'Guest\About::index');
$routes->get('/contact', 'Guest\Contact::index');
$routes->get('/katalog', 'Guest\Katalog::index');
$routes->get('/profil', 'Guest\Profil::index');
$routes->get('/katalog/kategori/(:any)', 'Guest\Katalog::filter/$1');
$routes->get('/katalog/(:any)', 'Guest\Katalog::detail/$1');
$routes->get('/keranjang', 'Guest\Keranjang::index', ['filter' => 'role:guest']);
$routes->get('/checkout', 'Guest\Checkout::index', ['filter' => 'role:guest']);
$routes->get('/checkout-barang', 'Guest\Checkout::beli', ['filter' => 'role:guest']);
$routes->get('/riwayat', 'Guest\Riwayat::index', ['filter' => 'role:guest']);
$routes->get('/riwayat/(:any)', 'Guest\Riwayat::detail/$1', ['filter' => 'role:guest']);


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
